/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author mayj
 */
public class employee {
    int ID;
    String username;
    String name;
    String password;
    
    employee(int ID, String un, String name, String pw){
        this.ID = ID;
        this.username = un;
        this.name = name;
        this.password = pw;
          
    }
}
