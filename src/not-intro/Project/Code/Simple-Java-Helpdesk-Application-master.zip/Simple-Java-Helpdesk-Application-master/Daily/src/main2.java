
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author mayj
 */
public class main2 {
    Connection con;
    Statement stmt;
    /**
     *
     * @param args
     */
    public static void main(String args[]){
    d2 d = new d2();
    d.insert();
    d.insert();
         } 
   } 

