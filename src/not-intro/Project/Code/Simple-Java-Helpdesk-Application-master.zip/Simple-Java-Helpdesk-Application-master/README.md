dial
====

A helpdesk ticketing system pet project. It uses standard Java Swing for GUI and JDBC for the database functions.

This project will look have similar function to a helpdesk ticketing system. 
This is to learn how to use JDBC and SQL to a certain degree.

Version .1 - basic build of CRUD functionality. Input, view, delete, and edit tickets.<br>
Version .15 - sorting of the tickets<br>
Version .2 user input interface<br>
Version .3 admin section<br>
Version .4 workers/admin section<br>
Version .5 .... not really sure<br>


To Build:
I personally use Netbeans.. I have not tried it on anything else.

Download the zip/Fork the project/whatever you want.

There is a database called TICKETS.grab. Use that file for the database creation.

Run the file
