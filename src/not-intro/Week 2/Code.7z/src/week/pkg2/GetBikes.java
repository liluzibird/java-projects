
package week.pkg2;


public class GetBikes
{
    public static void main(String[] args)
    {
        // TODO Auto-generated method stub
        
        MountainBike mb = new MountainBike(3, 100, 25);
        System.out.println(mb.toString());
    }
    
}
