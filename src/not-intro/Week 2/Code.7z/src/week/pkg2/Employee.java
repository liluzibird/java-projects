
package week.pkg2;


public class Employee
{
    
    int salary = 90000;
    String EmployeeName = "John Doe";
    String Address;
    String City;
    String State;
    int zip;
    int age;
    
}
