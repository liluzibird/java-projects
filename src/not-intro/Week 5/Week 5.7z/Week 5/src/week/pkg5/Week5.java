
package week.pkg5;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;


public class Week5 extends JFrame{
    
    public static void main(String[] args) {
    
    JFrame frame = new Week5();
   // frame.pack();
    frame.setSize(1000,100);
   frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    frame.setVisible(true);
    }
    JLabel lblScore1, lblScore2, lblScore3;
    JTextField txtScore1, txtScore2, txtScore3;
    JButton btnCalc, btnTransfer;

        // TODO code application logic here
        
    }