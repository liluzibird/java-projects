/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package m14;

/**
 *
 * @author User
 */
public class c2 {
    public static void main(String[] args) {
        
        c1 var = new c1();
        
        System.out.println("The name entered: " + var.getName());
        System.out.println("The age entered: " + var.getAge());
        System.out.println("The address entered: " + var.getPersonalInfo());
        
    }
    
}
