/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package m14;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class c7 {
    public static void main(String[] args) {
            int id;
    String name;
    float salary;
    
    Scanner scan = new Scanner (System.in);
    
    System.out.println("Enter the salary");
    s = scan.nextFloat();
    
    
}

public void display()
{
    System.out.println(id + " " + name + " " + salary);
}
    }
