/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package m13;

/**
 *
 * @author ACC
 */
public class CW1 {
    public static void main(String[] args) {
        for (int i = 1; i <= 20; i++)
        {
            System.out.println(i + " ");
        }
    }

    
}
