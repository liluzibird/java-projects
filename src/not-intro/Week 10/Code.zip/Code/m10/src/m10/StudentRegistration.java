/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package m10;

/**
 *
 * @author User
 */
public class StudentRegistration extends JFrame {
    statement stmt;
    
    JLabel lblStudentID, lblLastname, lblFirstname, lblAddress, lblCity, lblState, lblZipcode;
    JTextField txtStudentID, txtLastname, txtFirstname, txtAddress, txtCity, txtState, txtZipcode;
    JButton btnSubmit;
    
    
    public static void main(String[] args) {
        JFrame frame = new StudentRegistration();
        frame.pack();
        
        frame.setVisible(true);
        
    }
    
    
    public StudentRegistration()
    {
        JPanel p = new JPanel();
        
        p.add(lblStudentID = new JLabel ("StudentID"));
        p.add(txtStudentID = new JTextField (10)); 
        
        p.add(lblStudentID = new JLabel ("StudentID"));
        p.add(txtStudentID = new JTextField (10));     
        
        p.add(lblStudentID = new JLabel ("StudentID"));
        p.add(txtStudentID = new JTextField (10));      
        
        p.add(lblStudentID = new JLabel ("StudentID"));
        p.add(txtStudentID = new JTextField (10));      
        
        p.add(lblStudentID = new JLabel ("StudentID"));
        p.add(txtStudentID = new JTextField (10));      
        
        p.add(lblStudentID = new JLabel ("StudentID"));
        p.add(txtStudentID = new JTextField (10));       
        
        p.add(lblStudentID = new JLabel ("StudentID"));
        p.add(txtStudentID = new JTextField (10));
        
        p.add(btnSubmit = new JButton ("Submit"));
        
        add(p);
        
        
        btnSubmit.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                try{
                    
                Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
                    System.out.println("Driver connected");
                    
                    String url = "jdbc:ucanaccess://jdbc:ucanaccess://D:\\Skool\\SAC\\FALL 2022\\CMPR 113\\Week 10\\Code\\Studentsdb.accdb";
                    
                    Connection connect = DriverManager.getConnection(url);
                    
                    stmt = connect.createStatement();
                    
                    System.out.println("Database connected");
                    
                    String Query = "Select * from StudentCourses";
                    
                    ResultSet rset = stmt.executeQuery(Query);
                    
                    System.out.println("StudentID" + "Lastname" + "Firstname" + "Address" + + "City" + "State" + "CourseID" + "CourseInfo");
                    
                    while(rset.next())
                    {
                        System.out.println(rset.getString("StudentID") + ": " + 
                                rset.getString("Lastname") + ": " + 
                                rset.getString("Firstname") + ": " + 
                                rset.getString("Address") + ": " + 
                                rset.getString("City") + ": " + 
                                rset.getString("State") + ": " + 
                                rset.getString("Zipcode") + ": " + 
                                rset.getString("CourseID") + ": " + 
                                rset.getString("CourseInfo") + ": " + );
                    }
                    
                    
                }
                    
                }
            }
        }
        
        
    }
}
