import java.io.*;
import java.io.FileWriter;
import java.util.Scanner;

public class Project3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
				
				int test1, test2, test3, total, average;
				String firstname, lastname;
				Scanner scan = new Scanner(System.in);
				System.out.println("Enter first name: ");
				firstname = scan.nextLine();
				
				System.out.println("Enter Last Name: ");
				lastname = scan.nextLine();
				
				System.out.println("Enter First Score: ");
				test1 = scan.nextInt();
				
				System.out.println("Enter Second Score: ");
				test2 = scan.nextInt();
				
				System.out.println("Enter Third Score: ");
				test3 = scan.nextInt();
				
				total = (test1 + test2 + test3);
				
				average = (test1 + test2 + test3)/3;
				
				System.out.println("Welcome " + lastname + ", " + firstname + " your total score is ");
				
				System.out.println("First Test Score: " + test1);
				
				System.out.println("Second Test Score: " + test2);

				System.out.println("Third Test Score: " + test3);
				
				System.out.println("and your average score is " + average);
	
	while (average > 100 || average < 0)
		
	{
		System.out.println("Invalid input: cannot be less than 0 or greater than 100. Please try again.");
		test1 = scan.nextInt();
		test2 = scan.nextInt();
		test3 = scan.nextInt();
		average = (test1 + test2 + test3);
		
	}
	if(average >= 90 && average <= 100)
	{
		System.out.println("Average: " + average + " grade received A");
	}
	else if(average >= 80 && average < 90)
	{
		System.out.println("Average: " + average + " grade received B");
	}
	else if(average >= 70 && average < 80)
	{
		System.out.println("Average: " + average + " grade received C");
	}
	else if(average >= 60 && average < 70)
	{
		System.out.println("Average: " + average + " grade received D");
	}
	else
	{
		System.out.println("Average: " + average + " grade received F");
	}
	try {
		File t = new File("C:\\Users\\liluz\\Downloads\\cmpr112 final\\scores.txt");
		FileWriter fw = new FileWriter(t,true);
		fw.write("\n");
		fw.write("Welcome " + lastname + ", ");
		fw.write(firstname + ":");
		fw.write(" Total Score " + total);
		fw.write(" and your average score is " + average);
		fw.close();
		}catch(Exception ex)
	{
			System.out.println(ex.toString());
			System.out.println("Error");
	
}
}
}
