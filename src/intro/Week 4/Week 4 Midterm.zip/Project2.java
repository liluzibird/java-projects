import java.util.Scanner;

import javax.swing.JOptionPane;

public class Project2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
				String input;
				double test1, test2, test3, average;
				Scanner scan = new Scanner(System.in);
				
				input = JOptionPane.showInputDialog("Enter First Score: ");
				test1 = Double.parseDouble(input);
				
				input = JOptionPane.showInputDialog("Enter Second Score: ");
				test2 = Double.parseDouble(input);
				
				input = JOptionPane.showInputDialog("Enter Third Score: ");
				test3 = Double.parseDouble(input);
				
				average = (test1 + test2 + test3)/3;
				
				JOptionPane.showMessageDialog(null, "First Test Score: " + test1);
				
				JOptionPane.showMessageDialog(null, "Second Test Score: " + test2);

				JOptionPane.showMessageDialog(null, "Third Test Score: " + test3);
				
				JOptionPane.showMessageDialog(null, "Average Test Score: " + average);
	
	while (average > 100 || average < 0)
	{
		JOptionPane.showMessageDialog(null, "Invalid input: cannot be less than 0 or greater than 100. Please try again.");
		test1 = Double.parseDouble(input);
		test2 = Double.parseDouble(input);
		test3 = Double.parseDouble(input);
		average = (test1 + test2 + test3);
		
	}
	if(average >= 90 && average <= 100)
	{
		JOptionPane.showMessageDialog(null, "Average: " + average + " grade received A");
	}
	else if(average >= 80 && average < 90)
	{
		JOptionPane.showMessageDialog(null, "Average: " + average + " grade received B");
	}
	else if(average >= 70 && average < 80)
	{
		JOptionPane.showMessageDialog(null, "Average: " + average + " grade received C");
	}
	else if(average >= 60 && average < 70)
	{
		JOptionPane.showMessageDialog(null, "Average: " + average + " grade received D");
	}
	else
	{
		JOptionPane.showMessageDialog(null, "Average: " + average + " grade received F");
	}
	}
}
