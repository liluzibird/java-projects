
public class Project4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int n = 100;
		
		//print all even numbers <=n 
		for (int i=10; i<=n; n-=i) {

				System.out.println(n);
			}
	}}
	

